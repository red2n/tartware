# Service Consolidation Implementation Guide

## Quick Reference: Where Everything Goes

### ✅ KEEP AS-IS (5 Services)
```
1. api-gateway          → Entry point, auth, routing
2. core-service         → + settings-service content
3. reservations-service → (New consolidated service - see below)
4. billing-service      → (New consolidated service - see below)
5. notifications-worker → Simplified from notification-service
```

### 🔄 MERGE INTO RESERVATIONS-SERVICE
```
Source Services to Merge:
├── guests-service              → /src/modules/guests/
├── rooms-service               → /src/modules/rooms/
├── availability-guard-service  → /src/modules/inventory/
├── housekeeping-service        → /src/modules/housekeeping/
├── roll-service               → /src/modules/scheduling/
└── reservations-command-service → /src/modules/reservations/

Result: Single service with 6 internal modules
Database: reservations_db (consolidate all tables)
```

### 🔄 MERGE INTO BILLING-SERVICE
```
Source Services to Merge:
├── billing-service (keep as base)
├── cashier-service            → /src/modules/cashier/
├── accounts-service           → /src/modules/accounts/
└── finance-admin-service      → /src/modules/finance-admin/

Result: Single service with 4 internal modules  
Database: billing_db (consolidate all tables)
```

### 📚 CONVERT TO LIBRARY
```
calculation-service → @tartware/calculations
├── /src/tax/       (tax calculations)
├── /src/rates/     (rate calculations)
├── /src/yield/     (yield calculations)
├── /src/splits/    (split calculations)
├── /src/forex/     (forex calculations)
└── /src/kpi/       (KPI calculations)

Import as: import { calculateTax } from '@tartware/calculations';
```

### 🗑️ REMOVE
```
❌ command-center-service   → Use direct HTTP + Kafka events
❌ service-registry         → Use Kubernetes DNS
❌ recommendation-service   → Move to post-MVP backlog
```

### ⚠️ DEFER (Keep for Now, Review Later)
```
⏸️ revenue-service          → Legitimate bounded context
⏸️ guest-experience-service → Separate UI/API for guest portal
```

---

## Step-by-Step Consolidation Process

### Phase 1: Billing Service Consolidation (Week 1-2)

#### Step 1.1: Create Module Structure in billing-service
```bash
cd Apps/billing-service/src
mkdir -p modules/{billing,cashier,accounts,finance-admin}

# Move existing billing code into modules/billing
mv repositories modules/billing/
mv services modules/billing/
mv routes modules/billing/
```

#### Step 1.2: Copy Cashier Service Code
```bash
# Copy cashier code as a module
cp -r Apps/cashier-service/src/* Apps/billing-service/src/modules/cashier/

# Update imports in cashier code
# FROM: import { db } from '../db'
# TO:   import { db } from '../../shared/db'
```

#### Step 1.3: Copy Accounts Service Code
```bash
cp -r Apps/accounts-service/src/* Apps/billing-service/src/modules/accounts/
# Update imports similarly
```

#### Step 1.4: Copy Finance Admin Code
```bash
cp -r Apps/finance-admin-service/src/* Apps/billing-service/src/modules/finance-admin/
# Update imports similarly
```

#### Step 1.5: Consolidate Routes
```typescript
// Apps/billing-service/src/app.ts

import { billingRoutes } from './modules/billing/routes';
import { cashierRoutes } from './modules/cashier/routes';
import { accountsRoutes } from './modules/accounts/routes';
import { financeAdminRoutes } from './modules/finance-admin/routes';

app.register(billingRoutes, { prefix: '/v1/billing' });
app.register(cashierRoutes, { prefix: '/v1/cashier' });
app.register(accountsRoutes, { prefix: '/v1/accounts' });
app.register(financeAdminRoutes, { prefix: '/v1/finance-admin' });
```

#### Step 1.6: Consolidate Database
```sql
-- Merge all billing tables into billing_db

-- From billing-service
CREATE TABLE folios (...);
CREATE TABLE folio_line_items (...);
CREATE TABLE charge_routings (...);

-- From cashier-service  
CREATE TABLE cashier_sessions (...);
CREATE TABLE cashier_transactions (...);

-- From accounts-service
CREATE TABLE ar_accounts (...);
CREATE TABLE ar_aging (...);
CREATE TABLE invoices (...);

-- From finance-admin-service
CREATE TABLE fiscal_periods (...);
CREATE TABLE night_audit_logs (...);
```

#### Step 1.7: Update API Gateway
```typescript
// Apps/api-gateway/src/routes/billing.ts

// BEFORE: Multiple service routes
fastify.register(proxyToBillingService);
fastify.register(proxyToCashierService);
fastify.register(proxyToAccountsService);
fastify.register(proxyToFinanceAdminService);

// AFTER: Single service route
fastify.register(proxyToBillingService, {
  upstream: 'http://billing-service:3025',
  prefix: '/v1',
  rewritePrefix: '/v1'
});
```

#### Step 1.8: Extract Calculation Library
```bash
# Create new package
mkdir -p Apps/calculations
cd Apps/calculations

# Initialize package
npm init -y
# Edit package.json:
{
  "name": "@tartware/calculations",
  "version": "1.0.0",
  "type": "module",
  "exports": {
    ".": "./dist/index.js",
    "./tax": "./dist/tax.js",
    "./rates": "./dist/rates.js"
  }
}

# Move calculation code from calculation-service
cp -r ../calculation-service/src/* ./src/

# Build library
pnpm build

# Update billing-service package.json
{
  "dependencies": {
    "@tartware/calculations": "workspace:*"
  }
}
```

#### Step 1.9: Update Billing Service to Use Library
```typescript
// BEFORE: HTTP call to calculation-service
const taxResult = await fetch('http://calculation-service:3070/calculate-tax', {
  method: 'POST',
  body: JSON.stringify({ amount, rate })
});

// AFTER: Direct library call
import { calculateTax } from '@tartware/calculations';
const taxResult = calculateTax(amount, rate);
```

#### Step 1.10: Deploy & Validate
```bash
# Deploy consolidated billing-service
kubectl apply -f platform/kubernetes/billing-service.yaml

# Validate all endpoints work
./http_test/billing.http
./http_test/cashier.http
./http_test/accounts.http
./http_test/finance-admin.http

# Monitor logs for errors
kubectl logs -f deployment/billing-service

# Check metrics
curl http://billing-service:3025/metrics
```

#### Step 1.11: Decommission Old Services
```bash
# Scale down old services
kubectl scale deployment/cashier-service --replicas=0
kubectl scale deployment/accounts-service --replicas=0
kubectl scale deployment/finance-admin-service --replicas=0
kubectl scale deployment/calculation-service --replicas=0

# Monitor for 1 week, then delete
kubectl delete deployment/cashier-service
kubectl delete deployment/accounts-service
kubectl delete deployment/finance-admin-service
kubectl delete deployment/calculation-service
```

---

### Phase 2: Reservations Service Consolidation (Week 3-4)

#### Step 2.1: Create New Reservations Service Structure
```bash
mkdir -p Apps/reservations-service-v2/src/{modules,shared}
cd Apps/reservations-service-v2/src/modules

mkdir -p reservations/{repositories,services,routes,consumers}
mkdir -p guests/{repositories,services,routes}
mkdir -p rooms/{repositories,services,routes}
mkdir -p inventory/{repositories,services,grpc}
mkdir -p housekeeping/{repositories,services,routes,consumers}
mkdir -p scheduling/{workers,repositories}
```

#### Step 2.2: Module Structure
```
reservations-service-v2/
├── src/
│   ├── modules/
│   │   ├── reservations/      (from reservations-command-service)
│   │   │   ├── repositories/
│   │   │   │   ├── reservation-repository.ts
│   │   │   │   └── reservation-queries.ts
│   │   │   ├── services/
│   │   │   │   ├── reservation-service.ts
│   │   │   │   └── reservation-lifecycle.ts
│   │   │   ├── routes/
│   │   │   │   └── reservation-routes.ts
│   │   │   └── consumers/
│   │   │       └── reservation-consumer.ts
│   │   │
│   │   ├── guests/            (from guests-service)
│   │   │   ├── repositories/
│   │   │   │   └── guest-repository.ts
│   │   │   ├── services/
│   │   │   │   └── guest-service.ts
│   │   │   └── routes/
│   │   │       └── guest-routes.ts
│   │   │
│   │   ├── rooms/             (from rooms-service)
│   │   │   ├── repositories/
│   │   │   │   ├── room-repository.ts
│   │   │   │   └── room-type-repository.ts
│   │   │   ├── services/
│   │   │   │   ├── room-service.ts
│   │   │   │   └── availability-service.ts
│   │   │   └── routes/
│   │   │       └── room-routes.ts
│   │   │
│   │   ├── inventory/         (from availability-guard-service)
│   │   │   ├── repositories/
│   │   │   │   └── lock-repository.ts
│   │   │   ├── services/
│   │   │   │   └── inventory-lock-service.ts
│   │   │   └── grpc/
│   │   │       └── availability-guard.ts  (keep gRPC if needed internally)
│   │   │
│   │   ├── housekeeping/      (from housekeeping-service)
│   │   │   ├── repositories/
│   │   │   │   └── task-repository.ts
│   │   │   ├── services/
│   │   │   │   └── housekeeping-service.ts
│   │   │   ├── routes/
│   │   │   │   └── housekeeping-routes.ts
│   │   │   └── consumers/
│   │   │       └── room-status-consumer.ts
│   │   │
│   │   └── scheduling/        (from roll-service)
│   │       ├── workers/
│   │       │   └── lifecycle-worker.ts
│   │       └── repositories/
│   │           └── schedule-repository.ts
│   │
│   ├── shared/
│   │   ├── db/
│   │   │   └── connection.ts  (single connection pool)
│   │   ├── kafka/
│   │   │   └── producer.ts
│   │   └── utils/
│   │       └── transaction.ts
│   │
│   ├── app.ts
│   └── server.ts
```

#### Step 2.3: Consolidate Database Connections
```typescript
// src/shared/db/connection.ts

import { Pool } from 'pg';

// Single connection pool for all modules
export const db = new Pool({
  host: process.env.RESERVATIONS_DB_HOST,
  database: 'reservations_db',
  max: 50 // Increased from 10 per service
});

// Export for all modules
export { db };
```

#### Step 2.4: Consolidate Routes
```typescript
// src/app.ts

import { reservationRoutes } from './modules/reservations/routes';
import { guestRoutes } from './modules/guests/routes';
import { roomRoutes } from './modules/rooms/routes';
import { housekeepingRoutes } from './modules/housekeeping/routes';

export async function buildApp() {
  const app = fastify();

  // Register all module routes
  app.register(reservationRoutes, { prefix: '/v1/reservations' });
  app.register(guestRoutes, { prefix: '/v1/guests' });
  app.register(roomRoutes, { prefix: '/v1/rooms' });
  app.register(housekeepingRoutes, { prefix: '/v1/housekeeping' });

  return app;
}
```

#### Step 2.5: Example Cross-Module Transaction
```typescript
// src/modules/reservations/services/reservation-service.ts

import { db } from '../../shared/db';
import { guestRepository } from '../guests/repositories/guest-repository';
import { lockRepository } from '../inventory/repositories/lock-repository';

export async function createReservation(payload: CreateReservationPayload) {
  return db.transaction(async (client) => {
    // All operations in single transaction - no network calls!
    
    // 1. Create or get guest
    const guest = await guestRepository.upsertGuest(client, payload.guest);
    
    // 2. Lock inventory (same DB, no gRPC!)
    await lockRepository.lockRoom(client, {
      roomId: payload.roomId,
      checkIn: payload.checkIn,
      checkOut: payload.checkOut
    });
    
    // 3. Create reservation
    const reservation = await reservationRepository.create(client, {
      ...payload,
      guestId: guest.id
    });
    
    // 4. Publish event AFTER commit
    await kafkaProducer.send({
      topic: 'reservations.events',
      messages: [{
        key: reservation.id,
        value: JSON.stringify({
          type: 'reservation.created',
          data: reservation
        })
      }]
    });
    
    return reservation;
  });
}
```

#### Step 2.6: Database Consolidation
```sql
-- Create consolidated reservations_db

-- Reservations tables (from reservations-service)
CREATE TABLE reservations (...);
CREATE TABLE reservation_guests (...);

-- Guest tables (from guests-service)
CREATE TABLE guests (...);
CREATE TABLE guest_preferences (...);
CREATE TABLE guest_documents (...);

-- Room tables (from rooms-service)
CREATE TABLE rooms (...);
CREATE TABLE room_types (...);
CREATE TABLE room_amenities (...);

-- Inventory tables (from availability-guard-service)
CREATE TABLE inventory_locks (...);
CREATE TABLE inventory_locks_shadow (...);

-- Housekeeping tables (from housekeeping-service)
CREATE TABLE housekeeping_tasks (...);
CREATE TABLE room_inspections (...);

-- Scheduling tables (from roll-service)
CREATE TABLE scheduled_jobs (...);
```

#### Step 2.7: Migration Script
```typescript
// scripts/migrate-to-consolidated-reservations.ts

import { Client } from 'pg';

async function migrateReservationsData() {
  const sourceDBs = {
    reservations: new Client({ host: 'reservations-db', database: 'reservations' }),
    guests: new Client({ host: 'guests-db', database: 'guests' }),
    rooms: new Client({ host: 'rooms-db', database: 'rooms' }),
    inventory: new Client({ host: 'availability-guard-db', database: 'inventory' }),
    housekeeping: new Client({ host: 'housekeeping-db', database: 'housekeeping' })
  };
  
  const targetDB = new Client({ host: 'reservations-db', database: 'reservations_db' });
  
  await targetDB.connect();
  
  // Migrate in dependency order
  console.log('Migrating rooms...');
  await migrateRooms(sourceDBs.rooms, targetDB);
  
  console.log('Migrating guests...');
  await migrateGuests(sourceDBs.guests, targetDB);
  
  console.log('Migrating reservations...');
  await migrateReservations(sourceDBs.reservations, targetDB);
  
  console.log('Migrating inventory locks...');
  await migrateInventory(sourceDBs.inventory, targetDB);
  
  console.log('Migrating housekeeping...');
  await migrateHousekeeping(sourceDBs.housekeeping, targetDB);
  
  console.log('Migration complete!');
}

async function migrateRooms(source: Client, target: Client) {
  const rooms = await source.query('SELECT * FROM rooms');
  for (const room of rooms.rows) {
    await target.query(
      'INSERT INTO rooms (id, tenant_id, property_id, room_number, ...) VALUES ($1, $2, $3, $4, ...)',
      [room.id, room.tenant_id, room.property_id, room.room_number, ...]
    );
  }
}

// Run migration
migrateReservationsData().catch(console.error);
```

---

### Phase 3: Command Pattern Simplification (Week 5)

#### Remove Command Center Service

**BEFORE:**
```
Client → API Gateway → Command Center → Kafka → Domain Service
```

**AFTER:**
```
Client → API Gateway → Domain Service → Kafka (events only)
```

#### Step 3.1: Direct HTTP to Services
```typescript
// Apps/api-gateway/src/routes/reservations.ts

// BEFORE: Proxy to command-center
fastify.post('/v1/commands/reservation.create/execute', async (req, reply) => {
  return proxyToCommandCenter(req, reply);
});

// AFTER: Direct proxy to reservations-service
fastify.post('/v1/reservations', async (req, reply) => {
  return proxy({
    upstream: 'http://reservations-service:3020',
    rewritePrefix: '/v1/reservations'
  })(req, reply);
});
```

#### Step 3.2: Events for Cross-Context Communication
```typescript
// Apps/reservations-service/src/modules/reservations/services/reservation-service.ts

export async function createReservation(payload) {
  const reservation = await db.transaction(async (client) => {
    // Create reservation in DB
    return await reservationRepository.create(client, payload);
  });
  
  // Publish event AFTER successful commit
  await kafka.send({
    topic: 'reservations.events',
    messages: [{
      key: reservation.id,
      value: JSON.stringify({
        type: 'reservation.created',
        data: reservation,
        metadata: {
          tenantId: reservation.tenant_id,
          timestamp: new Date().toISOString()
        }
      })
    }]
  });
  
  return reservation;
}
```

#### Step 3.3: Billing Service Event Consumer
```typescript
// Apps/billing-service/src/consumers/reservation-events-consumer.ts

export async function consumeReservationEvents() {
  await kafka.consumer().subscribe({ topic: 'reservations.events' });
  
  await kafka.consumer().run({
    eachMessage: async ({ message }) => {
      const event = JSON.parse(message.value.toString());
      
      if (event.type === 'reservation.created') {
        // Auto-create folio for new reservation
        await billingService.createFolioForReservation(event.data);
      }
    }
  });
}
```

---

## Benefits Summary

### Before Consolidation
```
Services: 20
Deployment time: 45 minutes (20 services × 2-3 min each)
Network hops (create reservation): 5
Database connections: 100 (20 services × 5 connections)
Code duplication: High (shared patterns in 20 repos)
Cross-service transactions: Complex (distributed saga)
Developer onboarding: 6 weeks
```

### After Consolidation
```
Services: 5
Deployment time: 10 minutes (5 services × 2 min each)
Network hops (create reservation): 1
Database connections: 25 (5 services × 5 connections)
Code duplication: Low (shared libraries)
Cross-service transactions: Rare (within bounded contexts)
Developer onboarding: 2 weeks
```

### Operational Improvements
- ✅ **75% fewer deployment units**
- ✅ **80% reduction in network latency**
- ✅ **75% reduction in database connections**
- ✅ **Simpler debugging** (fewer services to trace through)
- ✅ **ACID transactions** within bounded contexts
- ✅ **No distributed sagas** for common operations

---

## Testing Checklist

### Consolidated Billing Service
- [ ] All billing endpoints work (`/v1/billing/*`)
- [ ] All cashier endpoints work (`/v1/cashier/*`)
- [ ] All accounts endpoints work (`/v1/accounts/*`)
- [ ] All finance-admin endpoints work (`/v1/finance-admin/*`)
- [ ] Calculation library functions correctly
- [ ] Database transactions span modules
- [ ] Performance is same or better than before

### Consolidated Reservations Service
- [ ] All reservation endpoints work
- [ ] All guest endpoints work
- [ ] All room endpoints work
- [ ] All housekeeping endpoints work
- [ ] Availability checks work (no gRPC errors)
- [ ] Cross-module transactions work
- [ ] Event publishing works
- [ ] Performance is same or better

### Integration Tests
- [ ] Create reservation → auto-creates folio (reservation → billing event)
- [ ] Payment received → sends notification (billing → notification event)
- [ ] Room cleaned → updates availability (housekeeping → reservation internal)
- [ ] No double bookings (inventory locking in same transaction)

---

## Rollback Plan

If consolidation causes issues:

1. **Keep old services running** for 1 week after deployment
2. **Route 10% traffic** to new consolidated service initially
3. **Monitor metrics** (latency, error rate, throughput)
4. **If issues detected:** Scale old services back up, route traffic back
5. **Once stable:** Gradually increase traffic to 100%, then decommission old services

---

## Next Steps

1. Review this guide with the team
2. Create GitHub issues for each phase
3. Start with Phase 1 (billing consolidation - lowest risk)
4. Measure improvements after each phase
5. Document lessons learned for remaining phases

Would you like me to create:
- [ ] Detailed migration scripts for specific services?
- [ ] Database consolidation SQL scripts?
- [ ] Docker Compose for local testing of consolidated services?
- [ ] Load test scripts to validate performance?
